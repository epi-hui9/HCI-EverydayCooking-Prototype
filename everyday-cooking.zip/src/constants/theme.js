import { PALETTE } from "../theme";

export const HOMEPAGE_BUTTON_COLORS = {
  yourFood: PALETTE.ecoMedium,
  recipes: PALETTE.accent,
  history: PALETTE.textTertiary,
  weeklyPlan: PALETTE.sageDark,
};
