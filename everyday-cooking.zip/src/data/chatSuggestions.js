/**
 * Suggested questions shown in the chat empty state.
 */
export const SUGGESTED_QUESTIONS = [
  "What can I cook with chicken and carrots?",
  "How do I store kale to keep it fresh longer?",
  "What can I make with my leftover rice?",
  "What recipes use ingredients from my pantry?",
];
